You receive a message that looks like a random jumble of numbers and letters. However, it seems oddly structured. Could it be that the message is represented in a different numerical format? Find the correct way to interpret it and retrieve the flag.

74 65 78 75 73 63 74 66 7b 68 65 78 5f 69 73 5f 66 75 6e 7d 0a