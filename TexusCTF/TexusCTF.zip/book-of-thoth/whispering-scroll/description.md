 A brittle parchment, stained with time, trembles in your hands. The ink shimmers under the moonlight, forming words long forgotten, riddles with foreign words depicted on it ,the echoes of gods 8000 years ago.

 Ciphertext: 籽籮粁籾籼籬籽籯粄籔籗簹籠籕簼籍籐簼籛籮籒籐籷簾粆