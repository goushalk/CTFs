Beyond the tapestry opens  a massive stone gate, weathered by time yet unyielding to force. At its base stands a figure—his robes tattered, his face obscured by a hood. His voice echoes, though his lips never move:

 
Riddle me this, if you dare to see,
 A truth long buried, a name set free.
The Book of Thoth is not for the blind,
 What men forget, the sands still find.
Through shifting dunes, where echoes loom,
 He uncovers stone beneath the gloom.
 A cipher carved, a secret drawn,
 A name once true, now turned to pawn.
Turn back time, retrace the past,
 Find the name that was first—at last.
Solve the riddle, speak it plain,
And through the gate, you shall take your regin.

Carved in the stone is “U3BlYWsgbm90IGl0cyBuYW1lLCBub3Igc2VlayBpdHMgcGFnZSwKRm9yIFRob3Ro4oCZcyBvd24gY3Vyc2UgZGVmaWVzIHRoZSBhZ2UuCkF0KCAyOS45NzkywrAgTiwgMzEuMTM0MsKwIEUgKWl0IHNsZWVwcywKRGlzdHVyYiBpdCBub3QsIGxlc3QgZGFya25lc3MgcmVhcHMu” 

