Attackers have concealed information within vast amounts of data before, and they might still be doing it.


