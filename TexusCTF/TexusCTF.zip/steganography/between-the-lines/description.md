This document about cybersecurity seems normal, but there's something hidden between the lines.
