This QR code works, but something seems off about it. Maybe there's more to it than meets the eye?
Pass = "qrsecret"